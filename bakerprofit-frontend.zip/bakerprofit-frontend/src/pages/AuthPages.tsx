import { Link, useNavigate } from 'react-router-dom';
import { Button, Card } from '../components/ui';

export function LoginPage() {
  const navigate = useNavigate();
  return (
    <div className="grid min-h-screen place-items-center bg-cream px-4 py-12">
      <Card className="w-full max-w-md">
        <div className="mb-8 text-center">
          <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-brand text-xl font-black text-white">BP</div>
          <h1 className="mt-4 text-3xl font-extrabold">BakerProfit OS</h1>
          <p className="mt-2 text-sm text-baker-muted">Never undercharge for your bakes again.</p>
        </div>
        <div className="space-y-4">
          <label className="block text-sm font-semibold">Email<input className="mt-1 w-full rounded-lg border border-baker-border px-3 py-2 outline-none focus:border-brand" placeholder="owner@boldmunch.co.uk" /></label>
          <label className="block text-sm font-semibold">Password<input type="password" className="mt-1 w-full rounded-lg border border-baker-border px-3 py-2 outline-none focus:border-brand" placeholder="••••••••" /></label>
          <button onClick={() => navigate('/dashboard')} className="w-full rounded-lg bg-brand px-4 py-2.5 font-bold text-white hover:bg-brand-dark">Login</button>
        </div>
        <p className="mt-5 text-center text-sm text-baker-muted">New bakery? <Link className="font-bold text-brand" to="/register">Create an account</Link></p>
      </Card>
    </div>
  );
}

export function RegisterPage() {
  return (
    <div className="grid min-h-screen place-items-center bg-cream px-4 py-12">
      <Card className="w-full max-w-lg">
        <div className="mb-8 text-center">
          <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-brand text-xl font-black text-white">BP</div>
          <h1 className="mt-4 text-3xl font-extrabold">Create BakerProfit OS</h1>
          <p className="mt-2 text-sm text-baker-muted">Set up your bakery workspace.</p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          {['Bakery Name', 'Full Name', 'Email', 'Password', 'Confirm Password'].map((field) => (
            <label key={field} className={field === 'Bakery Name' || field === 'Email' ? 'block text-sm font-semibold sm:col-span-2' : 'block text-sm font-semibold'}>
              {field}
              <input type={field.toLowerCase().includes('password') ? 'password' : 'text'} className="mt-1 w-full rounded-lg border border-baker-border px-3 py-2 outline-none focus:border-brand" />
            </label>
          ))}
        </div>
        <div className="mt-5"><Button>Create account</Button></div>
        <p className="mt-5 text-center text-sm text-baker-muted">Already registered? <Link className="font-bold text-brand" to="/login">Login</Link></p>
      </Card>
    </div>
  );
}

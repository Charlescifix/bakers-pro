import { useState } from 'react';

const nav = ['Dashboard', 'Ingredients', 'Recipes', 'Products', 'Customers', 'Quotes', 'Orders', 'Production', 'Shopping Lists', 'Reports', 'Intelligence', 'Allergens', 'Compliance', 'Settings'];

const rows = [
  ['BM-Q-00231', 'Tara Johnson', 'draft', '£280.00', '£116.40', '41.6%'],
  ['BM-Q-00230', 'Amaka Obi', 'accepted', '£96.00', '£51.20', '53.3%'],
];

export default function BakerProfitCanvasPreview() {
  const [active, setActive] = useState('Dashboard');

  return (
    <div className="min-h-screen bg-[#FFFDF9] text-[#1C1209] xl:grid xl:grid-cols-[280px_1fr]">
      <aside className="hidden border-r border-[#E8DDD0] bg-white p-5 xl:block">
        <div className="flex items-center gap-3 border-b border-[#E8DDD0] pb-5">
          <div className="grid h-12 w-12 place-items-center rounded-2xl bg-[#C97D2E] font-black text-white">BP</div>
          <div>
            <h1 className="font-extrabold">BakerProfit OS</h1>
            <p className="text-xs text-[#6B5744]">Never undercharge again</p>
          </div>
        </div>
        <nav className="mt-5 space-y-1">
          {nav.map((item) => (
            <button key={item} onClick={() => setActive(item)} className={`w-full rounded-xl px-3 py-2 text-left text-sm font-bold ${active === item ? 'bg-[#C97D2E] text-white' : 'text-[#6B5744] hover:bg-[#FDF6EC]'}`}>
              {item}
            </button>
          ))}
        </nav>
      </aside>

      <main>
        <header className="sticky top-0 flex h-20 items-center justify-between border-b border-[#E8DDD0] bg-[#FFFDF9]/90 px-6 backdrop-blur">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.18em] text-[#C97D2E]">Bold Munch</p>
            <h2 className="text-2xl font-extrabold">{active}</h2>
          </div>
          <div className="rounded-xl border border-[#E8DDD0] bg-white px-4 py-2 text-sm font-bold">Charles N · Owner</div>
        </header>

        <section className="p-6">
          <div className="mb-6 flex flex-col justify-between gap-4 lg:flex-row lg:items-end">
            <div>
              <p className="text-xs font-black uppercase tracking-[0.18em] text-[#C97D2E]">CRM Workspace</p>
              <h3 className="mt-1 text-3xl font-black">{active === 'Dashboard' ? 'Bold Munch command centre' : `${active} workspace`}</h3>
              <p className="mt-2 max-w-3xl text-sm leading-6 text-[#6B5744]">Left side lists the features. The full right side is reserved for tables, forms, details, previews and profit panels.</p>
            </div>
            <button className="rounded-xl bg-[#C97D2E] px-4 py-2 font-bold text-white">Primary Action</button>
          </div>

          {active === 'Dashboard' ? (
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
              {['Orders Today: 12', 'Open Quotes: 8', 'Week Revenue: £4,920', 'Net Profit: £1,748'].map((stat) => (
                <div key={stat} className="rounded-2xl border border-[#E8DDD0] bg-white p-5 shadow-sm">
                  <p className="text-sm text-[#6B5744]">{stat.split(':')[0]}</p>
                  <p className="mt-3 text-3xl font-black">{stat.split(':')[1]}</p>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid gap-4 xl:grid-cols-[1fr_340px]">
              <div className="rounded-2xl border border-[#E8DDD0] bg-white p-5 shadow-sm">
                <input className="w-full rounded-xl border border-[#E8DDD0] bg-[#FFFDF9] px-3 py-2" placeholder={`Search ${active.toLowerCase()}...`} />
                <table className="mt-4 w-full text-left text-sm">
                  <thead><tr>{['Ref', 'Customer', 'Status', 'Revenue', 'Profit', 'Margin'].map((h) => <th key={h} className="bg-[#FDF6EC] p-3 text-xs uppercase text-[#6B5744]">{h}</th>)}</tr></thead>
                  <tbody>{rows.map((row) => <tr key={row[0]}>{row.map((cell) => <td key={cell} className="border-b border-[#E8DDD0] p-3">{cell}</td>)}</tr>)}</tbody>
                </table>
              </div>
              <div className="rounded-2xl border border-[#E8DDD0] bg-white p-5 shadow-sm">
                <h4 className="font-black">Add / Edit Panel</h4>
                {['Customer', 'Sales Channel', 'Delivery Date', 'Line Items'].map((field) => <div key={field} className="mt-3 rounded-xl border border-[#E8DDD0] bg-[#FFFDF9] p-3 text-sm text-[#6B5744]">{field}</div>)}
              </div>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}

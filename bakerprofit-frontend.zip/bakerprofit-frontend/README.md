# BakerProfit OS Frontend Starter

A clean CRM-style frontend starter for BakerProfit OS / Bold Munch.

The UI follows a simple pattern:

- Left sidebar = all product areas and workflows
- Right content area = full-page working screen
- Dashboard first = quotes, orders, production, shopping and profit alerts
- Mobile = bottom navigation for Dashboard, Quotes, Orders and Production

## Stack

- React 19 + TypeScript
- Vite
- Tailwind CSS v4 via the Vite plugin
- React Router
- TanStack Query
- Axios with JWT refresh interceptor
- Recharts, TanStack Table, React Hook Form and Zod ready for deeper screens
- Lucide icons
- shadcn/ui compatible layout and styling patterns

## Folder structure

```txt
bakerprofit-frontend/
  src/
    components/
      AppShell.tsx       # CRM shell: sidebar, header, mobile nav
      ui.tsx             # Simple shadcn-style Card/Button/Badge components
    data/
      mock.ts            # Navigation, mock dashboard data, page configs
    lib/
      api.ts             # Axios client + JWT refresh logic
      format.ts          # Money, percent, margin colour helpers
    pages/
      AuthPages.tsx      # Login/register screens
      Dashboard.tsx      # BakerProfit command centre
      GenericPage.tsx    # CRM list + form panel template for all modules
    canvas/
      BakerProfitCanvasPreview.tsx
    App.tsx
    main.tsx
    styles.css
  canvas-preview.html    # Direct browser preview with no build step
```

## Run locally

```bash
cd bakerprofit-frontend
cp .env.example .env
npm install
npm run dev
```

Open the Vite URL, usually:

```txt
http://localhost:5173
```

## Preview without installing

Open `canvas-preview.html` in a browser. It is a static clickable mockup for quick review or canvas-style preview.

## Connect to your backend

The default API base URL is:

```txt
http://localhost:8000/api/v1
```

Change it in `.env`:

```txt
VITE_API_BASE_URL=http://localhost:8000/api/v1
```

The Axios client already attaches:

```txt
Authorization: Bearer <access_token>
```

It also attempts `POST /auth/refresh` on the first 401, stores the refreshed access and refresh tokens, retries the failed request, and redirects to `/login` if refresh fails.

## Suggested next build steps

1. Replace the mock rows in `src/data/mock.ts` with `useQuery` hooks per page.
2. Turn `GenericPage` into specific pages where deeper interaction is needed first: Quotes, Orders, Recipes and Ingredients.
3. Add shadcn/ui components:

```bash
npx shadcn@latest init
npx shadcn@latest add button card badge dialog sheet table form input select tabs toast skeleton dropdown-menu
```

4. Add forms gradually using React Hook Form + Zod.
5. Add role checks from `GET /auth/me` so staff cannot see cost/profit data and accountants are read-only.

## UX rules already reflected

- Warm bakery design system
- CRM left navigation and full right display
- Profit status badges and margin colours
- Skeleton-ready card/table structure
- Mobile bottom tab bar for key workflows
- Empty states and clear primary actions
- Internal API visibility panel while building
